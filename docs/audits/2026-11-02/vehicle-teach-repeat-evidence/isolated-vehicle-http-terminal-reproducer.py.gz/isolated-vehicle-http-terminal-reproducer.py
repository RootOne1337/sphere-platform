"""Replay SAVED HTTP evidence through controller only; recorded wall-clock values, not source-time pose stamps. No video inference, HTTP, or physical input."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));OUT=Path(__file__).resolve().parent
import numpy as np
from motor_worker.route_localization import SparseRoute,RoutePose
from motor_worker.vehicle_route import VehicleRouteFollower
from motor_worker.route_reference_view import reference_rotations
from scripts.pilot.route_hud_profile import load_speed_reference
rows=[json.loads(s)for s in(OUT/'samples.jsonl').read_text().splitlines()]
route=SparseRoute.load(ROOT/'.local-pilot/skuter1-guided-runtime-20261102-v3/route.json',sha256='75244ca44fd029d6e10e22d274be5c156e5ad0821cc852760f61ffe217f4697c')
geom=ROOT/'.local-pilot/skuter1-fused-graph-20261102-v2/track-filter-ba-20261102-v2/supported-3view-20261102-v1/geometry.json'
rot=reference_rotations(geom,route,'75e491be5dff83a4566414c903cc1c666dfb96b88ca0c713e7565de102bff1aa')
speed=load_speed_reference(ROOT/'.local-pilot/reconstruction-jobs/6a77040681d142ec97d51831a22785fb')
clock=[rows[0]['pose']['received_at']-.1]
f=VehicleRouteFollower(route,speed,clock=lambda:clock[0],reference_rotations=rot,start_mode='recognized_route',max_seconds=300,max_speed_kmh=15)
compared=[];mismatch=[];first=None;last_localized=None;last_following=None
for row in rows:
 data=dict(row['pose']);data['geometry']=tuple(data['geometry']);data['polyline_px']=tuple(tuple(v)for v in data['polyline_px'])
 for key in ('center','rotation'):
  if data[key]is not None:data[key]=tuple(data[key])
 pose=RoutePose(**data)
 # Actual response compute duration is a measured wall-clock upper bound on
 # follower call time by only its own sub-ms runtime; no media seconds used.
 clock[0]=pose.received_at+row['computeMs']/1000
 prior=dict(highWater=f.high_water,lastCenter=None if f.last_center is None else f.last_center.tolist(),waitingSince=f.waiting_since,started=f.started)
 answer=f.observe(pose,row['speedObservation'],motion_active=False)
 same=all(answer[k]==row['vehicle'][k]for k in ('phase','reason','pedal','steering'))
 if not same:mismatch.append(dict(sequence=row['sequence'],actual=row['vehicle'],replayed=answer))
 if answer['phase']=='stopped':
  first=dict(row=row,controllerBefore=prior,controllerAfter=dict(highWater=f.high_water,step=f.step,total=f.total),lastLocalized=last_localized,lastFollowing=last_following)
  break
 if pose.state=='localized':last_localized=row
 if answer['phase']=='following':last_following=row
 compared.append(dict(sequence=row['sequence'],matches=same))
assert first is not None
row=first['row'];idx=int(row['pose']['segment']);arc=f.arc;secs=np.asarray(route.source_seconds);trace=np.asarray(route.camera_trace)
left=max(0,min(len(secs)-2,int(np.searchsorted(secs,row['sourceSeconds'],side='right')-1)))
alpha=(row['sourceSeconds']-secs[left])/(secs[left+1]-secs[left])
interpolated=(1-alpha)*trace[left]+alpha*trace[left+1]
nearest=int(np.argmin(np.linalg.norm(trace-np.asarray(row['pose']['center']),axis=1)))
posthoc=dict(referenceInterval=dict(indices=[route.source_frame_indices[left],route.source_frame_indices[left+1]],seconds=[float(secs[left]),float(secs[left+1])]),sameTimeTraceProgress=float(np.interp(row['sourceSeconds'],secs,arc)),sameTimeCenterDifference=float(np.linalg.norm(np.asarray(row['pose']['center'])-interpolated)),nearestSpatialReference=dict(index=route.source_frame_indices[nearest],seconds=float(secs[nearest]),distance=float(np.linalg.norm(trace[nearest]-row['pose']['center']))),poseProgressDifferenceFromSameTimeTrace=float(row['pose']['progress_units']-np.interp(row['sourceSeconds'],secs,arc)),forwardAllowedUpper=first['controllerBefore']['highWater']+6*f.step,backwardAllowedLower=first['controllerBefore']['highWater']-2*f.step,traceStepMedianMoving=float(f.step),forwardDeltaSteps=float((row['pose']['progress_units']-first['controllerBefore']['highWater'])/f.step),observedHud=row['speedObservation']['speed_kmh'],userSpeedCap=row['vehicle']['maxSpeedKmh'])
result=dict(schema='sphere-recorded-controller-terminal-audit-v1',firstTerminal=first,posthocOnly=posthoc,comparedResponsesIncludingTerminal=len(compared)+1,mismatchCount=len(mismatch),mismatches=mismatch,clockBasis='recorded_actual_received_at_plus_measured_HTTP_handler_computeMs_upper_bound; no_source_clock; no_new_inference',notIndependentPoseTruth=True,physicalActions=0,reranHttp=False)
with(OUT/'terminal-audit.json').open('x',encoding='utf8')as out:json.dump(result,out,indent=2,allow_nan=False)
print(json.dumps(dict(mismatches=len(mismatch),terminalIndex=row['sourceIndex'],terminalSeconds=row['sourceSeconds'],posthoc=posthoc,lastLocalizedIndex=last_localized['sourceIndex'],lastLocalizedSeconds=last_localized['sourceSeconds'],lastFollowingIndex=last_following['sourceIndex'],lastFollowingSeconds=last_following['sourceSeconds'])))
